# Consultative Playbook Generator - Project Summary

## 🎯 Project Overview

A **standalone, production-ready AI-powered sales email and script generation system** for enterprise ABM (Account-Based Marketing). Built specifically for your use case: **scaling one person's winning consultative selling approach across a 2-5 person sales team in 2-3 weeks**.

**Key Constraint**: You have winning emails scattered across Gmail/Slack but no time to manually analyze them. This tool extracts patterns *automatically* and lets salespeople generate new emails immediately.

---

## ✨ What's Included

### Core Features (MVP)
✅ **Email Import & Analysis**
- Paste winning emails (bulk or individual)
- AI extracts opening hooks, core messages, closing tactics
- Identifies consultative selling principles used

✅ **Email Generation**
- Input: Company, role, problem hypothesis, recent hook
- Output: Full enterprise sales email grounded in your patterns
- Uses your playbook to stay on-brand and effective

✅ **Call Script Generation**
- Objectives: Discovery, demo debrief, objection handling, closing
- Output: Structured talking points + discovery questions + handles
- Based on consultative selling methodology

✅ **Edit Suggestions** (Phase 2, code ready)
- Paste a draft email
- Get feedback on strengths, gaps, specific improvements
- Learn from what works

### Technical Stack
- **Frontend**: Next.js 14 (App Router) + React 18 + TypeScript
- **Styling**: Tailwind CSS (mobile-first)
- **Backend**: Next.js API Routes
- **Database**: Supabase (PostgreSQL) with Row-Level Security
- **AI**: Anthropic API (Claude)
- **State**: Zustand
- **Code Quality**: No `any` types, Prettier formatting, strict TypeScript

---

## 📁 File Structure

```
consultative-playbook-generator/
├── app/
│   ├── layout.tsx                   # Root layout
│   ├── page.tsx                     # Main dashboard (tabs)
│   ├── globals.css                  # Global styles
│   └── api/
│       ├── analyze/route.ts         # Email pattern extraction
│       ├── generate-email/route.ts  # Email generation
│       ├── generate-script/route.ts # Script generation
│       └── suggest-edits/route.ts   # Suggestion feature (ready)
├── components/
│   ├── Button.tsx                   # Reusable button
│   ├── Input.tsx                    # Form input
│   ├── Textarea.tsx                 # Form textarea
│   ├── Card.tsx                     # Card wrapper
│   ├── EmailImportSection.tsx       # Import & analyze
│   ├── EmailGeneratorSection.tsx    # Generate emails
│   ├── ScriptGeneratorSection.tsx   # Generate scripts
│   └── PatternValidationSection.tsx # Phase 2 placeholder
├── lib/
│   ├── anthropic.ts                 # Anthropic API integration
│   ├── supabase.ts                  # Supabase client
│   ├── store.ts                     # Zustand state store
│   └── schema.sql                   # Database schema
├── types/
│   └── index.ts                     # All TypeScript types (no any)
├── package.json                     # Dependencies
├── tsconfig.json                    # TypeScript config
├── tailwind.config.js               # Tailwind config
├── next.config.js                   # Next.js config
├── .replit                          # Replit configuration
├── .env.local.example               # Environment template
├── README.md                        # Full documentation
├── REPLIT_QUICKSTART.md            # 5-minute setup guide
└── PROJECT_SUMMARY.md              # This file
```

---

## 🚀 Getting Started (Replit)

### 5-Minute Setup

1. **Fork to Replit**
   - Go to https://replit.com/new
   - Import from GitHub (or paste this repo)
   - Wait for dependencies

2. **Create `.env.local`**
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://...supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
   ANTHROPIC_API_KEY=sk-ant-...
   NEXT_PUBLIC_APP_URL=https://your-replit.replit.dev
   ```

3. **Set Up Supabase** (3 min)
   - Sign up at supabase.com
   - Create project
   - Run `lib/schema.sql` in SQL Editor
   - Copy URL and ANON KEY to `.env.local`

4. **Get Anthropic Key** (1 min)
   - Go to console.anthropic.com
   - Generate API key
   - Add to `.env.local`

5. **Run**
   ```bash
   npm install
   npm run dev
   ```

See `REPLIT_QUICKSTART.md` for detailed walk-through.

---

## 🔌 API Endpoints

All endpoints return JSON. All are ready to use.

### POST /api/analyze
**Analyze emails to extract patterns**

```json
Request: { "emails": ["email1", "email2"] }
Response: {
  "analysis": {
    "patterns": [...],
    "principles": ["consultative", "research-based"],
    "qualityScore": 85
  }
}
```

### POST /api/generate-email
**Generate email from context**

```json
Request: {
  "company": "Acme Corp",
  "role": "VP Engineering",
  "problemHypothesis": "Post-acquisition integration",
  "recentHook": "Acquired startup last month",
  "context": "cold"
}
Response: { "email": "Hi [Name],\n\nI've been tracking..." }
```

### POST /api/generate-script
**Generate call script**

```json
Request: {
  "objective": "discovery",
  "context": "VP Engineering post-acq"
}
Response: { "script": "OPENING:\nHi [Name]...\nDISCOVERY QUESTIONS:..." }
```

### POST /api/suggest-edits
**Get feedback on draft email**

```json
Request: { "draftEmail": "Hi [Name],..." }
Response: { "suggestions": "STRENGTHS:\n...\nGAPS:\n..." }
```

---

## 📊 Database Schema

**4 Main Tables** (all with Row-Level Security):

### playbooks
Extracted patterns from winning emails
```
id, user_id, name, deal_stage, persona, context,
opening_hook, core_message, closing_tactic,
extracted_principles, example_email, status, rating
```

### patterns
Individual pattern entries
```
id, user_id, pattern_type, pattern_text,
frequency, win_score, status
```

### generations
AI-generated emails & scripts
```
id, user_id, playbook_id, generated_email,
input_context (JSON), feedback, feedback_notes
```

### email_imports
Raw email uploads for analysis
```
id, user_id, email_text, analysis_result (JSON)
```

See `lib/schema.sql` for full definitions.

---

## 🧠 How the AI Works

The system uses **few-shot prompting** with your validated patterns:

1. **Extraction**: When you import emails, Claude analyzes them for:
   - Opening hooks (how they grab attention)
   - Core messages (problem hypothesis + specificity)
   - Closing tactics (how they ask for next step)
   - Underlying principles

2. **Generation**: When you generate new emails, Claude:
   - Gets your extracted principles in the system prompt
   - Uses them as guardrails for consistency
   - Generates contextual, specific output

3. **Improvement**: As your team uses the tool:
   - You track what gets sent as-is vs. heavily edited
   - System learns from feedback
   - Each month, patterns get sharper

**Key Design**: The prompt system is *extractable*, not *frozen*. You can always see and modify the patterns.

---

## 🔐 Security & Privacy

✅ **Row-Level Security (RLS)**: Users only see their own data
✅ **API Keys**: Stored in `.env.local`, never committed
✅ **Type Safety**: TypeScript prevents runtime errors
✅ **Input Validation**: All endpoints validate
✅ **No Secrets in Code**: Environment variables only

---

## 📈 Timeline & Roadmap

### Week 1 (Now)
- Deploy to Replit
- Import 25-50 winning emails
- Review extracted patterns

### Week 2-3
- Generate 5-10 emails
- Team tests them
- Gather feedback on quality

### Week 4+
- Full team adoption
- Track which emails win meetings
- Add more examples to improve

### Month 2 (Phase 2)
- [ ] Pattern validation UI
- [ ] Gmail integration (track opens)
- [ ] Team collaboration
- [ ] Analytics dashboard
- [ ] A/B testing framework

---

## 🎯 Usage Patterns

### For You (Owner)
1. Upload your winning emails
2. Review patterns extracted
3. Adjust system if needed (edit prompts)
4. Share Replit URL with team

### For Salespeople
1. Go to "Generate Email" tab
2. Fill in company/role/problem/hook
3. Get email in <5 seconds
4. Copy or customize
5. Send
6. Rate output (helps system improve)

### For Sales Ops
- Monitor usage trends
- See what patterns are being generated
- Gather feedback on AI quality
- Plan Phase 2 features (analytics, tracking)

---

## 🛠️ Customization Points

Easy to change (no code required):
- **Prompt system** (edit in `lib/anthropic.ts`)
- **UI styling** (Tailwind classes in components)
- **Email tone** (adjust system prompt)
- **Call objectives** (add more in `ScriptGeneratorSection`)

Requires code:
- **Database schema** (add new fields)
- **New features** (playbook management, A/B testing)
- **Integrations** (Gmail, Slack, Salesforce)

---

## 🧪 Testing

### Test Email Import
1. Go to "Import Emails" tab
2. Paste 2-3 sales emails
3. Click "Analyze Patterns"
4. Verify patterns extracted

### Test Email Generation
1. Go to "Generate Email" tab
2. Fill form:
   - Company: "Your Company"
   - Role: "VP Engineering"
   - Problem: "Post-acquisition integration complexity"
   - Hook: "They acquired a startup last month"
3. Click "Generate Email"
4. Copy and review

### Test Scripts
1. Go to "Generate Script" tab
2. Select "Discovery" objective
3. Add context: "VP Engineering post-acquisition"
4. Click "Generate Script"
5. Review talking points

---

## 📚 Key Dependencies

| Package | Purpose | Version |
|---------|---------|---------|
| next | React framework | ^14.0.0 |
| react | UI library | ^18.2.0 |
| typescript | Type safety | ^5.0.0 |
| tailwindcss | Styling | ^3.3.0 |
| @supabase/supabase-js | Database | ^2.38.0 |
| @anthropic-ai/sdk | AI API | ^0.7.0 |
| zustand | State | ^4.4.0 |

All are production-tested and widely used.

---

## 🚨 Troubleshooting

### App won't start
```bash
# Kill old process
lsof -ti:3000 | xargs kill -9
# Reinstall
npm install
npm run dev
```

### "Missing Supabase variables"
- Check `.env.local` exists in project root
- Verify URLs/keys don't have extra quotes
- Restart server (`Ctrl+C` then `npm run dev`)

### "Failed to generate email"
- Check Anthropic API key in Supabase dashboard
- Verify API key has available credits
- Check browser console for full error

### "Pattern analysis error"
- Ensure emails are >50 characters each
- Try with 2-3 example emails first
- Check console for Anthropic API errors

See `README.md` for more troubleshooting.

---

## 🔗 Useful Links

- **Docs**
  - [Next.js](https://nextjs.org/docs)
  - [Supabase](https://supabase.com/docs)
  - [Anthropic API](https://docs.anthropic.com)
  - [Tailwind CSS](https://tailwindcss.com)

- **Resources**
  - [Project README](./README.md) - Full documentation
  - [Replit Quick Start](./REPLIT_QUICKSTART.md) - 5-minute setup
  - [Database Schema](./lib/schema.sql) - SQL definitions

---

## 📞 Support Strategy

### For You (Owner)
- Check README.md for API details
- Review `lib/anthropic.ts` to tweak prompts
- Modify component styling via Tailwind

### For Team Users
- Share REPLIT_QUICKSTART.md (simplified guide)
- Create sample emails in "Generate Email" section
- Pin Replit URL for easy access

### For Issues
1. Check browser console (F12)
2. Check Replit logs (bottom panel)
3. Verify environment variables
4. Test API endpoints individually

---

## 🎓 Next Steps

### Immediate (Today)
1. Read REPLIT_QUICKSTART.md (5 min)
2. Set up Supabase and Anthropic (5 min)
3. Deploy to Replit (2 min)
4. Import 3-5 test emails (5 min)
5. Generate 1 test email (2 min)

### This Week
1. Import your 25-50 winning emails
2. Test email generation
3. Share Replit URL with team
4. Get initial feedback

### Next Week
1. Gather usage data (what's being generated)
2. Analyze email quality from recipients
3. Refine system prompt based on feedback
4. Plan Phase 2 features

---

## 📝 Notes

This is a **production-ready MVP** that follows your project constitution:
- ✅ Next.js + Tailwind + Supabase + TypeScript
- ✅ No `any` types
- ✅ Mobile-first responsive design
- ✅ Strict code standards
- ✅ Ready to deploy to Replit

The code is clean, documented, and extensible. Add Phase 2 features by following the same patterns.

---

**Built in ~3 hours, production-ready in 2-3 weeks of use.**

Good luck! 🚀
