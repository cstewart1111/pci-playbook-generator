# 🚀 Deployment Checklist (2-3 hours)

## Phase 1: Prerequisites (30 min)

### Get API Keys & URLs

- [ ] **Anthropic API Key**
  - [ ] Sign up at https://console.anthropic.com
  - [ ] Create/generate API key
  - [ ] Copy key (you'll need it in .env.local)
  - [ ] Verify API key has available credits

- [ ] **Supabase Project**
  - [ ] Sign up at https://supabase.com
  - [ ] Create new project (region: us-east-1 or closest to you)
  - [ ] Wait for project to initialize (~2 min)
  - [ ] Navigate to Settings > API
  - [ ] Copy "Project URL" → This is `NEXT_PUBLIC_SUPABASE_URL`
  - [ ] Copy "anon" key → This is `NEXT_PUBLIC_SUPABASE_ANON_KEY`

- [ ] **Replit URL**
  - [ ] Have Replit project open
  - [ ] You'll use the final URL (format: https://[project-name].replit.dev)

---

## Phase 2: Database Setup (10 min)

### Create Tables in Supabase

- [ ] In Supabase dashboard, go to SQL Editor
- [ ] Click "New Query"
- [ ] Copy entire contents of `lib/schema.sql`
- [ ] Paste into Supabase SQL editor
- [ ] Click "Run" (green play button)
- [ ] Wait for "Success" message
- [ ] Verify in Database menu:
  - [ ] `playbooks` table exists
  - [ ] `patterns` table exists
  - [ ] `generations` table exists
  - [ ] `email_imports` table exists
- [ ] Check Authentication > Providers:
  - [ ] Email & Password enabled (should be default)

---

## Phase 3: Environment Configuration (5 min)

### Create `.env.local` in Replit

- [ ] In Replit file browser, create new file: `.env.local`
- [ ] Copy this template:
  ```
  NEXT_PUBLIC_SUPABASE_URL=https://[project-id].supabase.co
  NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ0eXAiOiJKV1QiLCJhbGc...
  ANTHROPIC_API_KEY=sk-ant-...
  NEXT_PUBLIC_APP_URL=https://[your-replit-project].replit.dev
  NODE_ENV=development
  ```

- [ ] Fill in actual values:
  - `NEXT_PUBLIC_SUPABASE_URL` → from Supabase Settings > API
  - `NEXT_PUBLIC_SUPABASE_ANON_KEY` → from Supabase Settings > API
  - `ANTHROPIC_API_KEY` → from console.anthropic.com
  - `NEXT_PUBLIC_APP_URL` → will be visible after first `npm run dev`

- [ ] **Important**: Don't add extra quotes around values
  - ✅ Correct: `ANTHROPIC_API_KEY=sk-ant-xyz123`
  - ❌ Wrong: `ANTHROPIC_API_KEY="sk-ant-xyz123"`

---

## Phase 4: Dependencies & Build (5 min)

### Install and Test

- [ ] In Replit terminal, run:
  ```bash
  npm install
  ```
  Wait for all packages to install (~2-3 min)

- [ ] Build the project:
  ```bash
  npm run build
  ```
  Should complete with no errors

- [ ] If build fails:
  - [ ] Delete `node_modules` folder
  - [ ] Run `npm install` again
  - [ ] Run `npm run build` again

---

## Phase 5: Run Locally (5 min)

### Start Development Server

- [ ] In Replit terminal, run:
  ```bash
  npm run dev
  ```

- [ ] Wait for message:
  ```
  ▲ Next.js 14.x.x
  - ready started server on 0.0.0.0:3000, url: https://[project-name].replit.dev
  ```

- [ ] Click the URL or "Open in new tab" button
- [ ] Verify app loads with logo and tabs visible
- [ ] You should see:
  - Header: "📧 Playbook Generator"
  - Tabs: "📧 Import Emails", "🎯 Validate Patterns", "✉️ Generate Email", "🎙️ Generate Script"

---

## Phase 6: Test Basic Functionality (10 min)

### Test Email Analysis

- [ ] Click "Import Emails" tab
- [ ] In the textarea, paste this sample email:
  ```
  Hi [Name],
  
  I've been tracking how companies like yours navigate 
  post-acquisition integration challenges. I noticed you 
  recently acquired [Company], and integrating engineering 
  teams is typically the biggest complexity most founders 
  overlook.
  
  The teams that succeed are usually the ones that:
  1. Establish clear communication protocols early
  2. Map out integration dependencies before day 1
  3. Create a 90-day alignment roadmap
  
  I'm curious if any of this resonates with where you're at. 
  Would be open to a quick 15-minute conversation if helpful.
  
  Best,
  [Your Name]
  ```

- [ ] Click "Analyze Patterns"
- [ ] Wait 3-5 seconds
- [ ] Verify you see:
  - [ ] "Patterns Found" section
  - [ ] Quality Score (should be 70+)
  - [ ] Extracted patterns (opening hook, core message, closing)

### Test Email Generation

- [ ] Click "Generate Email" tab
- [ ] Fill form:
  - Company: `TechCorp`
  - Role: `VP Engineering`
  - Problem: `Post-acquisition integration complexity`
  - Hook: `They acquired a startup last month`
- [ ] Click "Generate Email"
- [ ] Wait 3-5 seconds
- [ ] Verify you see generated email (~3 paragraphs)
- [ ] Click "Copy to Clipboard"
- [ ] Paste somewhere to verify content copied

### Test Script Generation

- [ ] Click "Generate Script" tab
- [ ] Select objective: `Discovery`
- [ ] Add context: `VP Engineering at TechCorp, post-acquisition integration challenges`
- [ ] Click "Generate Script"
- [ ] Wait 3-5 seconds
- [ ] Verify you see structured script with:
  - [ ] OPENING section
  - [ ] DISCOVERY QUESTIONS
  - [ ] KEY POINTS
  - [ ] OBJECTION HANDLES
  - [ ] CLOSING

---

## Phase 7: Prepare for Team Usage (5 min)

### Document Setup for Team

- [ ] Share Replit URL with team members
- [ ] Create team channel message:
  ```
  🎉 New tool ready to use!
  
  📧 Consultative Playbook Generator
  https://[your-replit-url].replit.dev
  
  What it does:
  1. Generate sales emails based on your winning patterns
  2. Create call scripts for different scenarios
  3. Get feedback on draft emails
  
  How to use:
  1. Go to "Import Emails" → paste your best winning emails
  2. Go to "Generate Email" → fill in company/role/problem
  3. Copy the generated email and customize for the prospect
  
  Try it out and give feedback!
  ```

- [ ] Send link to team
- [ ] Gather initial feedback

---

## Phase 8: Add Your Winning Emails (30 min)

### Build Your Playbook

- [ ] Gather your 25-50 best/winning sales emails
- [ ] Go to "Import Emails" tab
- [ ] Paste emails in batches of 5-10 (separated by blank lines or ---)
- [ ] Click "Analyze Patterns"
- [ ] Note patterns extracted
- [ ] Repeat until all emails analyzed

- [ ] Review patterns:
  - [ ] Do they match your actual approach?
  - [ ] Are principles accurate?
  - [ ] Quality scores reasonable?

---

## Troubleshooting During Setup

### Issue: "npm install" fails

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules
rm -rf node_modules

# Reinstall
npm install
```

### Issue: ".env.local not found" error

**Solution:**
- Make sure `.env.local` file exists in project root (same level as package.json)
- Restart Replit server: `Ctrl+C` then `npm run dev`

### Issue: "Cannot find module @anthropic-ai/sdk"

**Solution:**
```bash
npm install @anthropic-ai/sdk --save
npm run dev
```

### Issue: "Cannot connect to Supabase"

**Check:**
- [ ] URL in `.env.local` is correct (should be `https://xxx.supabase.co`)
- [ ] ANON KEY in `.env.local` is correct
- [ ] No extra quotes around values
- [ ] Restart server: `Ctrl+C` then `npm run dev`

### Issue: "Failed to generate email" error

**Check:**
- [ ] Anthropic API key is correct and has credits
- [ ] Go to https://console.anthropic.com to verify
- [ ] Check browser console (F12) for full error message

### Issue: "Missing Supabase variables"

**Solution:**
1. Kill server: `Ctrl+C`
2. Edit `.env.local`, verify all 5 variables
3. Restart: `npm run dev`

---

## ✅ Deployment Complete Checklist

- [ ] Supabase project created
- [ ] Database tables initialized (schema.sql run)
- [ ] `.env.local` file created with all 5 variables
- [ ] npm install completed
- [ ] `npm run dev` running without errors
- [ ] App loads in browser
- [ ] Email analysis test passed
- [ ] Email generation test passed
- [ ] Script generation test passed
- [ ] Team has access to Replit URL
- [ ] Initial emails imported and analyzed

---

## 📊 Success Metrics (After 1 Week)

- [ ] Team has generated 5+ emails using the tool
- [ ] Feedback on email quality gathered
- [ ] At least 1 generated email got a positive response from prospect
- [ ] System prompts refined based on team usage
- [ ] Identified patterns in what works best

---

## 📝 Next Steps

### Week 1-2
- Import all 25-50 winning emails
- Generate and test emails
- Gather team feedback

### Week 3+
- Track which generated emails win meetings
- Refine prompts based on results
- Plan Phase 2 features:
  - [ ] Gmail integration (track opens)
  - [ ] Analytics dashboard
  - [ ] A/B testing framework
  - [ ] Playbook management UI

---

## 🆘 Still Stuck?

Check in this order:
1. Replit logs (bottom of screen)
2. Browser console (F12 > Console tab)
3. `.env.local` file (all 5 variables correct?)
4. README.md (full troubleshooting section)
5. ARCHITECTURE.md (understand data flow)

---

**Total time: ~1 hour to full deployment** ⏱️
