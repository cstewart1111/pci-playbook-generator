# Architecture & Data Flow

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CONSULTATIVE PLAYBOOK GENERATOR               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                  Next.js Frontend (React)                    │   │
│  ├──────────────────────────────────────────────────────────────┤   │
│  │                                                               │   │
│  │  📧 Email Import Tab   ✉️  Email Generator Tab              │   │
│  │  ├─ Paste emails      ├─ Company input                     │   │
│  │  ├─ Click analyze     ├─ Role selection                    │   │
│  │  └─ View patterns     ├─ Problem hypothesis                │   │
│  │                        └─ Generate → Copy/Share             │   │
│  │                                                               │   │
│  │  🎯 Pattern Validation Tab (Phase 2)   🎙️ Script Tab      │   │
│  │  ├─ Thumbs up/down    ├─ Select objective                  │   │
│  │  ├─ Create playbooks  ├─ Add context                       │   │
│  │  └─ Save patterns     └─ Generate talking points           │   │
│  │                                                               │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                           ↓ (HTTP Requests)                         │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │              Next.js API Routes (Backend)                    │   │
│  ├──────────────────────────────────────────────────────────────┤   │
│  │                                                               │   │
│  │  POST /api/analyze                                           │   │
│  │   ↓ Input: emails                                            │   │
│  │   ↓ Processing: Anthropic API                               │   │
│  │   ↓ Output: patterns, principles, qualityScore              │   │
│  │                                                               │   │
│  │  POST /api/generate-email                                   │   │
│  │   ↓ Input: company, role, problem, hook                     │   │
│  │   ↓ Processing: Few-shot Claude prompt                      │   │
│  │   ↓ Output: full email                                       │   │
│  │                                                               │   │
│  │  POST /api/generate-script                                  │   │
│  │   ↓ Input: objective, context                               │   │
│  │   ↓ Processing: Structured prompt                           │   │
│  │   ↓ Output: talking points + discovery questions            │   │
│  │                                                               │   │
│  │  POST /api/suggest-edits                                    │   │
│  │   ↓ Input: draft email                                       │   │
│  │   ↓ Processing: Analysis + feedback                         │   │
│  │   ↓ Output: strengths, gaps, suggestions                    │   │
│  │                                                               │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                    ↓                      ↓                          │
│        ┌──────────────────┐   ┌──────────────────────┐              │
│        │  Supabase        │   │   Anthropic API      │              │
│        │  (PostgreSQL)    │   │   (Claude)           │              │
│        ├──────────────────┤   ├──────────────────────┤              │
│        │ • playbooks      │   │ • Text generation    │              │
│        │ • patterns       │   │ • Pattern extraction │              │
│        │ • generations    │   │ • Edit suggestions   │              │
│        │ • email_imports  │   │ • Few-shot learning  │              │
│        │                  │   │ • ~100ms response    │              │
│        │ RLS enabled      │   │                      │              │
│        │ for security     │   │ API key: .env.local  │              │
│        └──────────────────┘   └──────────────────────┘              │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘

Deployment: Replit (or Vercel, Docker, self-hosted)
```

---

## 🔄 Data Flow Diagrams

### Import & Analysis Flow

```
User: Paste emails
   ↓
┌─────────────────────────────────────────────┐
│ EmailImportSection Component                │
│ ├─ Parse emails (split by delimiters)      │
│ └─ POST /api/analyze                        │
│    └─ Request: ["email1", "email2", ...]   │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ API Route: /api/analyze                     │
│ ├─ Receive emails                           │
│ └─ Call: analyzeEmailsForPatterns()         │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ Anthropic API (Claude)                      │
│ System Prompt:                              │
│  "Analyze these emails for:                 │
│   1. Opening hooks                          │
│   2. Core messages                          │
│   3. Closing tactics                        │
│   4. Principles"                            │
│ ├─ Input: raw email text                    │
│ └─ Output: JSON with patterns               │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ API Response to Frontend                    │
│ {                                           │
│   "analysis": {                             │
│     "patterns": [                           │
│       {                                     │
│         "type": "opening_hook",             │
│         "text": "Research-based obs...",    │
│         "examples": [...]                   │
│       }                                     │
│     ],                                      │
│     "principles": ["consultative", ...],   │
│     "qualityScore": 85                      │
│   }                                         │
│ }                                           │
└─────────────────────────────────────────────┘
   ↓
User: Reviews patterns
   ↓
Saved in Frontend State (Zustand)
```

### Email Generation Flow

```
User: Fill form
   ├─ Company: "Acme Corp"
   ├─ Role: "VP Engineering"
   ├─ Problem: "Post-acq integration"
   └─ Hook: "Acquired startup last month"
   ↓
┌─────────────────────────────────────────────┐
│ EmailGeneratorSection Component             │
│ └─ POST /api/generate-email                 │
│    └─ Request: {company, role, problem...}  │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ API Route: /api/generate-email              │
│ ├─ Receive context                          │
│ ├─ (Optional) Fetch playbook from Supabase  │
│ └─ Call: generateEmail(request, playbook)   │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ Anthropic API (Claude - Sonnet)             │
│                                             │
│ System Prompt (Dynamic):                    │
│  "You are a senior enterprise sales         │
│   strategist. Your approach:                │
│   1. Research their world deeply            │
│   2. Lead with problem, not pitch           │
│   3. Use specific examples                  │
│   4. Invite to explore together             │
│   5. Soft next step                         │
│                                             │
│   WINNING PATTERNS (if playbook):           │
│   - Opening: 'Research-based obs...'        │
│   - Core: 'Problem hypothesis + data'       │
│   - Close: 'Soft ask / calendar'            │
│   - Principles: [consultative, ...]         │
│                                             │
│  User Prompt:                               │
│   'Generate a cold outreach email           │
│    to VP Engineering at Acme Corp.          │
│    Problem: Post-acq integration            │
│    Hook: Acquired startup last month'"      │
│                                             │
│ Output: Full email (3-4 paragraphs)         │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ API Response to Frontend                    │
│ {                                           │
│   "success": true,                          │
│   "email": "Hi [Name],\n\nI've been         │
│    tracking how teams at companies\n       │
│    like yours navigate the complexity       │
│    of integrating newly acquired            │
│    engineering teams...\n\n..."             │
│ }                                           │
└─────────────────────────────────────────────┘
   ↓
User: 
├─ Copy email
├─ Edit & customize
└─ Send to prospect
   ↓
(Future: Track opens/replies via Gmail API)
```

### Call Script Generation Flow

```
User: Select script objective
   ├─ Objective: "Discovery"
   └─ Context: "VP Engineering post-acq integration"
   ↓
┌─────────────────────────────────────────────┐
│ ScriptGeneratorSection Component            │
│ └─ POST /api/generate-script                │
│    └─ Request: {objective, context}         │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ API Route: /api/generate-script             │
│ ├─ Validate objective (discovery,           │
│ │  demo_debrief, objection, closing)        │
│ ├─ (Optional) Fetch playbook                │
│ └─ Call: generateScript(request, playbook)  │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ Anthropic API (Claude)                      │
│                                             │
│ System Prompt: Same methodology as emails   │
│                                             │
│ User Prompt:                                │
│  "Generate a discovery call script           │
│   for VP Engineering post-acq               │
│   integration challenge.                    │
│                                             │
│   Structure:                                │
│   1. Opening (5-10 sec)                    │
│   2. Discovery Questions (3-4)              │
│   3. Key Points                             │
│   4. Objection Handles                      │
│   5. Closing"                               │
│                                             │
│ Output: Structured talking points           │
└─────────────────────────────────────────────┘
   ↓
┌─────────────────────────────────────────────┐
│ API Response                                │
│ {                                           │
│   "success": true,                          │
│   "script": "OPENING:\n                     │
│    Hi [Name], thanks for making             │
│    time. I've been tracking how             │
│    teams navigate post-acq                  │
│    integration...\n\n                       │
│    DISCOVERY QUESTIONS:\n                   │
│    1. How many people are on..."             │
│ }                                           │
└─────────────────────────────────────────────┘
   ↓
User: Practice call using script as guide
```

---

## 🗄️ Database Schema (Simplified)

```
┌─────────────────┐
│ auth.users      │
│ (Supabase Auth) │
└────────┬────────┘
         │
         │ user_id (FK)
         │
    ┌────┴───────────────────────────────────┐
    │                                         │
┌───▼──────────────┐                 ┌──────▼────────────┐
│ playbooks        │                 │ patterns           │
├──────────────────┤                 ├────────────────────┤
│ id (PK)          │                 │ id (PK)            │
│ user_id (FK)     │                 │ user_id (FK)       │
│ name             │                 │ pattern_type       │
│ deal_stage       │                 │ pattern_text       │
│ persona          │                 │ frequency          │
│ context          │                 │ win_score          │
│ opening_hook     │                 │ status             │
│ core_message     │                 │ created_at         │
│ closing_tactic   │                 └────────────────────┘
│ principles[]     │
│ example_email    │        ┌────────────────────┐
│ status           │        │ generations        │
│ rating           │        ├────────────────────┤
│ created_at       │───────▶│ id (PK)            │
└──────────────────┘        │ user_id (FK)       │
                            │ playbook_id (FK)   │
                            │ generated_email    │
                            │ input_context(JSON)│
                            │ feedback           │
                            │ feedback_notes     │
                            │ created_at         │
                            └────────────────────┘

┌────────────────────┐
│ email_imports      │
├────────────────────┤
│ id (PK)            │
│ user_id (FK)       │
│ email_text         │
│ analysis_result(JSON)
│ created_at         │
└────────────────────┘
```

---

## 🔌 API Request/Response Patterns

### Pattern 1: Async Generation

```
Request:
POST /api/generate-email
Content-Type: application/json
{
  "company": "string",
  "role": "string",
  "problemHypothesis": "string",
  "recentHook": "string",
  "context": "cold|warm|followup|objection",
  "playbookId": "string (optional)"
}

Response (200 OK):
{
  "success": true,
  "email": "string (full email text)"
}

Response (400 Bad Request):
{
  "error": "Missing required fields: ..."
}

Response (404 Not Found):
{
  "error": "Playbook not found"
}

Response (500 Server Error):
{
  "error": "Failed to generate email: [reason]"
}
```

### Pattern 2: Analysis Response

```
Request:
POST /api/analyze
Content-Type: application/json
{
  "emails": ["string", "string", ...]
}

Response (200 OK):
{
  "success": true,
  "analysis": {
    "patterns": [
      {
        "type": "opening_hook|core_message|closing",
        "text": "string (description)",
        "examples": ["string", "string"],
        "confidence": 0-1
      }
    ],
    "principles": ["string", "string"],
    "qualityScore": 0-100
  }
}
```

---

## 🔐 Security Layers

```
┌─────────────────────────────────────────────┐
│ Layer 1: Environment Variables              │
│ ├─ API keys never in code                   │
│ ├─ .env.local never committed               │
│ └─ Different keys per environment           │
└─────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────┐
│ Layer 2: TypeScript Type Safety             │
│ ├─ No 'any' types allowed                   │
│ ├─ Strict null checking                     │
│ └─ Input validation at compile time         │
└─────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────┐
│ Layer 3: Runtime Input Validation           │
│ ├─ Check required fields exist               │
│ ├─ Validate field types                     │
│ └─ Reject invalid values                    │
└─────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────┐
│ Layer 4: Supabase RLS                       │
│ ├─ Users only access own data               │
│ ├─ Policies on all tables                   │
│ └─ auth.uid() checks on SELECT/INSERT       │
└─────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────┐
│ Layer 5: API Rate Limiting                  │
│ ├─ Anthropic API key scoped usage           │
│ ├─ Monitor costs via console.anthropic.com  │
│ └─ Reasonable limits per user               │
└─────────────────────────────────────────────┘
```

---

## 📊 Performance Characteristics

| Operation | Time | Cost | Notes |
|-----------|------|------|-------|
| Email Analysis | 2-5s | ~$0.01/email | Depends on length |
| Email Generation | 2-4s | ~$0.01/email | Using Claude Sonnet |
| Script Generation | 3-5s | ~$0.02/script | Longer output |
| Edit Suggestions | 2-3s | ~$0.01/draft | Fast analysis |

*Costs are approximate and depend on usage patterns.*

---

## 🚀 Scaling Considerations

### Small Team (2-5 people)
- ✅ Replit (free tier works)
- ✅ Supabase free tier (~1M emails stored)
- ✅ Anthropic ~$10-50/month with usage
- **No database scaling needed**

### Growing Team (5-20 people)
- Consider: Vercel (faster)
- Monitor: Anthropic costs
- Plan: Analytics dashboard

### Enterprise (20+ people)
- Required: Self-hosted or Vercel Pro
- Required: Custom CRM integration
- Required: Advanced analytics

---

**Architecture is clean, extensible, and production-ready for your 2-3 person team.**
