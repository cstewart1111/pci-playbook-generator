# Consultative Playbook Generator

Scale your winning enterprise sales emails across your team with AI-powered generation, call scripts, and edit suggestions.

## 🎯 What This Does

- **📧 Email Import & Analysis**: Paste your winning emails → system extracts patterns
- **✉️ Email Generation**: Generate new emails using your proven patterns
- **🎙️ Call Script Generation**: Generate talking points for discovery, demos, objections, closing
- **🎯 Edit Suggestions**: Get feedback on draft emails you've written

## 🚀 Quick Start (Replit)

### Prerequisites

- Replit account (free)
- Supabase account (free tier works)
- Anthropic API key

### Step 1: Clone to Replit

1. Go to https://replit.com/new
2. Choose "Import from GitHub"
3. Paste your repo URL (or fork this one)
4. Wait for dependencies to install

### Step 2: Set Up Environment Variables

In Replit, create `.env.local`:

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url_here
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key_here

# Anthropic
ANTHROPIC_API_KEY=your_anthropic_api_key_here

# App
NEXT_PUBLIC_APP_URL=https://your-replit-url.replit.dev
NODE_ENV=development
```

### Step 3: Set Up Supabase Database

1. Go to [Supabase Dashboard](https://supabase.com)
2. Create a new project
3. Go to SQL Editor
4. Copy the contents of `lib/schema.sql` and run it in the SQL editor
5. Wait for all tables to be created
6. Get your URL and ANON_KEY from Settings > API

### Step 4: Get Anthropic API Key

1. Go to [Anthropic Console](https://console.anthropic.com)
2. Generate an API key
3. Add to `.env.local`

### Step 5: Run

```bash
npm install
npm run dev
```

The app will be live at your Replit URL (usually `https://[project-name].replit.dev`).

---

## 📁 Project Structure

```
.
├── app/
│   ├── layout.tsx          # Root layout
│   ├── page.tsx            # Main dashboard with tabs
│   ├── globals.css         # Global styles
│   └── api/
│       ├── analyze/        # Email pattern extraction
│       ├── generate-email/ # Email generation
│       ├── generate-script/# Script generation
│       └── suggest-edits/  # Edit suggestions (Phase 2)
├── components/
│   ├── Button.tsx
│   ├── Input.tsx
│   ├── Textarea.tsx
│   ├── Card.tsx
│   ├── EmailImportSection.tsx
│   ├── EmailGeneratorSection.tsx
│   ├── ScriptGeneratorSection.tsx
│   └── PatternValidationSection.tsx
├── lib/
│   ├── anthropic.ts        # Anthropic API integration
│   ├── supabase.ts         # Supabase client
│   ├── store.ts            # Zustand state management
│   └── schema.sql          # Database schema
├── types/
│   └── index.ts            # TypeScript type definitions
└── package.json
```

---

## 🔑 API Endpoints

### POST /api/analyze

Analyze emails and extract patterns.

**Request:**
```json
{
  "emails": ["Email content 1", "Email content 2"]
}
```

**Response:**
```json
{
  "success": true,
  "analysis": {
    "patterns": [
      {
        "type": "opening_hook",
        "text": "Research-based observation about their industry",
        "examples": ["example 1", "example 2"]
      }
    ],
    "principles": ["principle 1", "principle 2"],
    "qualityScore": 85
  }
}
```

### POST /api/generate-email

Generate an email based on context.

**Request:**
```json
{
  "company": "Acme Corp",
  "role": "VP Engineering",
  "problemHypothesis": "Post-acquisition integration complexity",
  "recentHook": "Acquired YCombinator startup last month",
  "context": "cold",
  "playbookId": "optional-playbook-id"
}
```

**Response:**
```json
{
  "success": true,
  "email": "Hi [Name],\n\nI've been tracking how teams..."
}
```

### POST /api/generate-script

Generate a call script.

**Request:**
```json
{
  "objective": "discovery",
  "context": "VP Engineering at TechCorp, post-acquisition integration",
  "playbookId": "optional-playbook-id"
}
```

**Response:**
```json
{
  "success": true,
  "script": "OPENING:\nHi [Name], thanks for taking the time..."
}
```

### POST /api/suggest-edits

Suggest edits to a draft email.

**Request:**
```json
{
  "draftEmail": "Hi [Name],\n\nI wanted to reach out...",
  "playbookId": "optional-playbook-id"
}
```

**Response:**
```json
{
  "success": true,
  "suggestions": "STRENGTHS:\n- Good specific hook\n\nGAPS:\n- Missing recent context..."
}
```

---

## 🏗️ Architecture

### Frontend (Next.js 14 + React 18)
- Server & client components
- Tailwind CSS for styling
- Zustand for state management
- Mobile-first responsive design

### Backend (Next.js API Routes)
- Supabase for authentication & database
- Anthropic API for AI generation
- TypeScript for type safety (no `any` types)

### Database (Supabase/PostgreSQL)
- `playbooks` - Extracted patterns from winning emails
- `patterns` - Individual pattern entries
- `generations` - AI-generated emails & scripts
- `email_imports` - Raw email uploads
- Row-Level Security (RLS) enabled

---

## 🔐 Security

- **RLS Enabled**: Users can only see their own data
- **API Key Protection**: All API keys stored in `.env.local` (never committed)
- **Type Safety**: TypeScript prevents runtime errors
- **Input Validation**: All API endpoints validate inputs

---

## 📊 Usage Flow

### Week 1: Setup & Import
1. Set up Replit + Supabase + Anthropic
2. Import your 25-50 winning emails
3. Review patterns extracted

### Week 2: Generate & Refine
1. Generate emails for new prospects
2. Test with 5-10 emails
3. Gather feedback on quality

### Week 3+: Scale & Iterate
1. Share with team
2. Track which generated emails win meetings
3. Add more winning examples to improve patterns

---

## 🚀 Deployment to Production

### Option 1: Replit (Recommended for <100 users)

The app already runs on Replit. Just set up the environment variables:

1. In Replit Secrets (click lock icon):
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `ANTHROPIC_API_KEY`

2. Your Replit URL becomes your production URL

3. Share the URL with your team

### Option 2: Vercel (For scale)

```bash
git push origin main
# Go to vercel.com/new
# Import from GitHub
# Set environment variables in Vercel dashboard
# Deploy
```

### Option 3: Docker / Self-hosted

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN npm install
RUN npm run build
CMD ["npm", "start"]
```

---

## 🔧 Development

### Install Dependencies
```bash
npm install
```

### Run Locally
```bash
npm run dev
# http://localhost:3000
```

### Format Code
```bash
npm run format
```

### Build for Production
```bash
npm run build
npm start
```

---

## 📋 Supabase Setup Checklist

- [ ] Create Supabase project
- [ ] Run `schema.sql` in SQL editor
- [ ] Get URL from Settings > API
- [ ] Get ANON KEY from Settings > API
- [ ] Enable email auth in Authentication > Providers
- [ ] Add `.env.local` with credentials
- [ ] Test connection from app

---

## 🎯 MVP Features (Week 1-3)

✅ Email import & pattern extraction
✅ Email generation
✅ Call script generation
✅ Mobile-responsive UI
✅ Replit deployment ready

## 🔜 Phase 2 Features (Month 2+)

- [ ] Pattern validation UI
- [ ] Playbook management (save, organize, rate)
- [ ] Edit suggestions feature
- [ ] Gmail integration (track opens, replies)
- [ ] Team collaboration & ratings
- [ ] Analytics dashboard
- [ ] A/B testing framework

---

## 🐛 Troubleshooting

### "Missing Supabase environment variables"
- Check `.env.local` exists and has correct keys
- Restart Replit server

### "API Key error from Anthropic"
- Check ANTHROPIC_API_KEY in `.env.local`
- Verify API key has available credits

### "Failed to analyze emails"
- Check that emails have enough content (>50 chars each)
- Try with 2-3 example emails first

### Port already in use
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9
npm run dev
```

---

## 📚 References

- [Next.js Docs](https://nextjs.org/docs)
- [Tailwind CSS](https://tailwindcss.com)
- [Supabase Docs](https://supabase.com/docs)
- [Anthropic API Docs](https://docs.anthropic.com)
- [TypeScript Handbook](https://www.typescriptlang.org/docs)

---

## 📝 License

MIT

---

## 🤝 Support

Questions? Issues?
1. Check troubleshooting above
2. Review error messages in browser console
3. Check Replit logs for backend errors
4. Test API endpoints individually

---

**Built with**: Next.js • Tailwind • Supabase • Anthropic
